import { ForbiddenException, NotFoundException } from '@nestjs/common';
import { describe, expect, it, jest } from '@jest/globals';
import { UserRole } from '@prisma/client';
import type { RequestUser } from '../auth/decorator/current-user.decorator';
import { PrismaService } from '../prisma/prisma.service';
import { PaginationQueryDto } from '../common/dto/pagination-query.dto';
import { AttendanceService } from './attendance.service';

describe('AttendanceService.findTeacherAttendance', () => {
  const teacherUser: RequestUser = {
    id: 'teacher-user-1',
    supabaseUserId: 'teacher-auth-1',
    sub: 'teacher-auth-1',
    email: 'teacher@example.test',
    role: UserRole.TEACHER,
    schoolId: 'school-1',
  };

  function setup(options: {
    assignments?: { classId: string }[];
    classExists?: boolean;
    assignmentExists?: boolean;
    studentExists?: boolean;
    records?: { id: string }[];
    total?: number;
  } = {}) {
    const records = options.records ?? [{ id: 'attendance-1' }];
    const prisma = {
      schoolMembership: {
        findFirst: jest.fn(async () => ({ schoolId: 'school-1' })),
      },
      teacher: {
        findFirst: jest.fn(async () => ({ id: 'teacher-1' })),
      },
      classTeacher: {
        findMany: jest.fn(
          async () => options.assignments ?? [{ classId: 'class-1' }],
        ),
        findUnique: jest.fn(async () =>
          options.assignmentExists === false
            ? null
            : { classId: 'class-1', teacherId: 'teacher-1' },
        ),
      },
      schoolClass: {
        findFirst: jest.fn(async () =>
          options.classExists === false ? null : { id: 'class-1' },
        ),
      },
      student: {
        findFirst: jest.fn(async () =>
          options.studentExists === false ? null : { id: 'student-1' },
        ),
      },
      attendance: {
        findMany: jest.fn(async () => records),
        count: jest.fn(async () => options.total ?? 3),
      },
    };

    return {
      service: new AttendanceService(prisma as unknown as PrismaService),
      prisma,
      records,
    };
  }

  it('limits paginated attendance to assigned classes and tenant school', async () => {
    const { service, prisma, records } = setup({
      assignments: [{ classId: 'class-1' }, { classId: 'class-2' }],
    });
    const query = new PaginationQueryDto();
    query.page = 2;
    query.limit = 1;

    await expect(
      service.findTeacherAttendance(teacherUser, query),
    ).resolves.toEqual({
      data: records,
      meta: { page: 2, limit: 1, total: 3, totalPages: 3 },
    });

    expect(prisma.schoolMembership.findFirst).toHaveBeenCalledWith({
      where: { userId: teacherUser.id, schoolId: teacherUser.schoolId },
    });
    expect(prisma.teacher.findFirst).toHaveBeenCalledWith({
      where: { userId: teacherUser.id, schoolId: 'school-1' },
    });
    expect(prisma.classTeacher.findMany).toHaveBeenCalledWith({
      where: {
        teacherId: 'teacher-1',
        class: { schoolId: 'school-1' },
      },
      select: { classId: true },
    });
    expect(prisma.attendance.findMany).toHaveBeenCalledWith({
      where: {
        classId: { in: ['class-1', 'class-2'] },
        class: { schoolId: 'school-1' },
      },
      include: { student: true, class: true },
      orderBy: [{ date: 'desc' }, { id: 'asc' }],
      skip: 1,
      take: 1,
    });
    expect(prisma.attendance.count).toHaveBeenCalledWith({
      where: {
        classId: { in: ['class-1', 'class-2'] },
        class: { schoolId: 'school-1' },
      },
    });
  });

  it('rejects users who are not teachers before querying attendance', async () => {
    const { service, prisma } = setup();

    await expect(
      service.findTeacherAttendance({
        ...teacherUser,
        role: UserRole.STUDENT,
      }),
    ).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.schoolMembership.findFirst).not.toHaveBeenCalled();
    expect(prisma.attendance.findMany).not.toHaveBeenCalled();
  });

  it('returns paginated attendance for a class assigned to the teacher', async () => {
    const { service, prisma, records } = setup();
    const query = new PaginationQueryDto();
    query.page = 2;
    query.limit = 1;

    await expect(
      service.findTeacherClassAttendance('class-1', teacherUser, query),
    ).resolves.toEqual({
      data: records,
      meta: { page: 2, limit: 1, total: 3, totalPages: 3 },
    });

    expect(prisma.schoolClass.findFirst).toHaveBeenCalledWith({
      where: { id: 'class-1', schoolId: 'school-1' },
      select: { id: true },
    });
    expect(prisma.classTeacher.findUnique).toHaveBeenCalledWith({
      where: {
        classId_teacherId: {
          classId: 'class-1',
          teacherId: 'teacher-1',
        },
      },
    });
    expect(prisma.attendance.findMany).toHaveBeenCalledWith({
      where: {
        classId: 'class-1',
        class: {
          schoolId: 'school-1',
          teachers: { some: { teacherId: 'teacher-1' } },
        },
      },
      include: { student: true, class: true },
      orderBy: [{ date: 'desc' }, { id: 'asc' }],
      skip: 1,
      take: 1,
    });
  });

  it('rejects a class that is not assigned to the teacher', async () => {
    const { service, prisma } = setup({ assignmentExists: false });

    await expect(
      service.findTeacherClassAttendance('class-1', teacherUser),
    ).rejects.toBeInstanceOf(ForbiddenException);
    expect(prisma.attendance.findMany).not.toHaveBeenCalled();
  });

  it('hides classes outside the teacher school and returns empty pages for assigned classes', async () => {
    const outsideSchool = setup({ classExists: false });

    await expect(
      outsideSchool.service.findTeacherClassAttendance(
        'other-school-class',
        teacherUser,
      ),
    ).rejects.toBeInstanceOf(NotFoundException);
    expect(outsideSchool.prisma.classTeacher.findUnique).not.toHaveBeenCalled();

    const emptyPage = setup({ records: [], total: 0 });
    await expect(
      emptyPage.service.findTeacherClassAttendance('class-1', teacherUser),
    ).resolves.toEqual({
      data: [],
      meta: { page: 1, limit: 20, total: 0, totalPages: 0 },
    });
  });

  it('returns student attendance only after an active enrollment in an assigned class', async () => {
    const { service, prisma, records } = setup();
    const query = new PaginationQueryDto();
    query.page = 2;
    query.limit = 1;

    await expect(
      service.findTeacherStudentAttendance('student-1', teacherUser, query),
    ).resolves.toEqual({
      data: records,
      meta: { page: 2, limit: 1, total: 3, totalPages: 3 },
    });

    expect(prisma.student.findFirst).toHaveBeenCalledWith({
      where: {
        id: 'student-1',
        schoolId: 'school-1',
        enrollments: {
          some: {
            status: 'ACTIVE',
            classId: { in: ['class-1'] },
            class: { schoolId: 'school-1' },
          },
        },
      },
      select: { id: true },
    });
    expect(prisma.attendance.findMany).toHaveBeenCalledWith({
      where: {
        studentId: 'student-1',
        classId: { in: ['class-1'] },
        class: {
          schoolId: 'school-1',
          teachers: { some: { teacherId: 'teacher-1' } },
        },
      },
      include: { student: true, class: true },
      orderBy: [{ date: 'desc' }, { id: 'asc' }],
      skip: 1,
      take: 1,
    });
  });

  it('does not disclose attendance for unrelated or out-of-school students', async () => {
    const unrelated = setup({ studentExists: false });

    await expect(
      unrelated.service.findTeacherStudentAttendance(
        'unrelated-student',
        teacherUser,
      ),
    ).rejects.toBeInstanceOf(NotFoundException);
    expect(unrelated.prisma.attendance.findMany).not.toHaveBeenCalled();

    const otherSchool = setup({ studentExists: false });
    await expect(
      otherSchool.service.findTeacherStudentAttendance(
        'other-school-student',
        teacherUser,
      ),
    ).rejects.toBeInstanceOf(NotFoundException);
    expect(otherSchool.prisma.student.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({ schoolId: 'school-1' }),
      }),
    );
    expect(otherSchool.prisma.attendance.findMany).not.toHaveBeenCalled();
  });

  it('keeps the existing student and administrative attendance queries intact', async () => {
    const { service, prisma, records } = setup();

    await expect(
      service.findMine({ ...teacherUser, role: UserRole.STUDENT }),
    ).resolves.toBe(records);
    expect(prisma.student.findFirst).toHaveBeenCalledWith({
      where: { userId: teacherUser.id },
    });
    expect(prisma.attendance.findMany).toHaveBeenCalledWith({
      where: { studentId: 'student-1' },
      include: { class: true, teacher: true },
      orderBy: { date: 'desc' },
    });

    const admin: RequestUser = {
      ...teacherUser,
      id: 'admin-user-1',
      role: UserRole.SCHOOL_ADMIN,
    };
    await expect(service.findAll(admin)).resolves.toBe(records);
    expect(prisma.attendance.findMany).toHaveBeenLastCalledWith({
      where: { class: { schoolId: 'school-1' } },
      include: { student: true, class: true, teacher: true },
      orderBy: { date: 'desc' },
    });
  });
});
