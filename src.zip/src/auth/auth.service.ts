import {
  ConflictException,
  Injectable,
  ServiceUnavailableException,
  UnauthorizedException,
} from '@nestjs/common';

import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
import { RequestUser } from './decorator/current-user.decorator';

import { PrismaService } from '../prisma/prisma.service';

import * as bcrypt from 'bcrypt';

import { JwtService } from '@nestjs/jwt';
import { UserRole } from '@prisma/client';
import { createHash, randomBytes } from 'crypto';
import { EmailService } from '../common/email.service';
import { ForgotPasswordDto } from './dto/forgot-password.dto';
import { ResetPasswordDto } from './dto/reset-password.dto';

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly email: EmailService,
  ) {}

  async register(registerDto: RegisterDto) {
    const existingUser = await this.prisma.user.findUnique({
      where: {
        email: registerDto.email,
      },
    });

    if (existingUser) {
      throw new ConflictException('This email already exists');
    }

    const hashedPassword = await bcrypt.hash(registerDto.password, 10);

    const user = await this.prisma.user.create({
      data: {
        email: registerDto.email,
        password: hashedPassword,
        firstName: registerDto.firstName,
        lastName: registerDto.lastName,
        phone: registerDto.phone,
        role: UserRole.SCHOOL_ADMIN,
      },
    });

    return {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      phone: user.phone,
      role: user.role,
    };
  }

  async changePassword(user: RequestUser, dto: ChangePasswordDto) {
    const existing = await this.prisma.user.findUnique({
      where: { id: user.id },
    });
    if (!existing) throw new UnauthorizedException('User not found');
    const valid = await bcrypt.compare(dto.currentPassword, existing.password);
    if (!valid)
      throw new UnauthorizedException('Current password is incorrect');
    await this.prisma.$transaction([
      this.prisma.user.update({
        where: { id: existing.id },
        data: { password: await bcrypt.hash(dto.newPassword, 10) },
      }),
      this.prisma.passwordResetToken.deleteMany({
        where: { userId: existing.id, usedAt: null },
      }),
    ]);
    return { message: 'Password changed successfully' };
  }

  async forgotPassword(dto: ForgotPasswordDto) {
    this.email.assertConfigured();
    const appUrl = process.env.APP_URL;
    if (!appUrl) {
      throw new ServiceUnavailableException('APP_URL is not configured');
    }

    const user = await this.prisma.user.findUnique({
      where: { email: dto.email },
    });

    if (user) {
      const token = randomBytes(32).toString('hex');
      const tokenHash = createHash('sha256').update(token).digest('hex');
      const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

      await this.prisma.$transaction([
        this.prisma.passwordResetToken.deleteMany({
          where: { userId: user.id, usedAt: null },
        }),
        this.prisma.passwordResetToken.create({
          data: { userId: user.id, tokenHash, expiresAt },
        }),
      ]);

      try {
        await this.email.send(
          user.email,
          'Reset your password',
          `Use this link within one hour to reset your password: ${appUrl.replace(/\/$/, '')}/reset-password?token=${token}`,
        );
      } catch (error) {
        await this.prisma.passwordResetToken.deleteMany({
          where: { tokenHash },
        });
        throw error;
      }
    }

    return {
      message: 'If the account exists, a password reset email has been sent.',
    };
  }

  async resetPassword(dto: ResetPasswordDto) {
    const tokenHash = createHash('sha256').update(dto.token).digest('hex');
    const now = new Date();
    const token = await this.prisma.passwordResetToken.findFirst({
      where: { tokenHash, usedAt: null, expiresAt: { gt: now } },
    });

    if (!token) {
      throw new UnauthorizedException(
        'Password reset token is invalid or expired',
      );
    }

    const password = await bcrypt.hash(dto.password, 10);
    await this.prisma.$transaction(async (tx) => {
      const consumed = await tx.passwordResetToken.updateMany({
        where: {
          id: token.id,
          usedAt: null,
          expiresAt: { gt: now },
        },
        data: { usedAt: now },
      });

      if (consumed.count !== 1) {
        throw new UnauthorizedException(
          'Password reset token is invalid or expired',
        );
      }

      await tx.user.update({
        where: { id: token.userId },
        data: { password },
      });
      await tx.passwordResetToken.deleteMany({
        where: { userId: token.userId, id: { not: token.id } },
      });
    });

    return { message: 'Password reset successfully' };
  }

  async login(loginDto: LoginDto) {
    const existingUser = await this.prisma.user.findUnique({
      where: {
        email: loginDto.email,
      },
    });

    if (!existingUser) {
      throw new UnauthorizedException('Invalid email or password');
    }

    if (existingUser.status !== 'ACTIVE') {
      throw new UnauthorizedException('This account is not active');
    }

    const passwordMatch = await bcrypt.compare(
      loginDto.password,
      existingUser.password,
    );

    if (!passwordMatch) {
      throw new UnauthorizedException('Invalid email or password');
    }

    const payload = {
      sub: existingUser.id,
      email: existingUser.email,
      role: existingUser.role,
    };

    const token = await this.jwtService.signAsync(payload);

    return {
      access_token: token,
    };
  }
}
