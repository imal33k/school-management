import {
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';

import {
  ExaminationStatus,
  Prisma,
  UserRole,
} from '@prisma/client';
import { GradingService } from '../grading/grading.service';
import { gradeFor, percentageOf } from '../grading/grading.logic';
import { PrismaService } from '../prisma/prisma.service';
import { RequestUser } from '../auth/decorator/current-user.decorator';

import { CreateResultDto } from './dto/create-result.dto';
import { UpdateResultDto } from './dto/update-result.dto';

@Injectable()
export class ResultsService {
  constructor(private readonly prisma: PrismaService, private readonly gradingService: GradingService) {}

  private async getMembership(user: RequestUser) {
    const membership = await this.prisma.schoolMembership.findFirst({
      where: {
        userId: user.id,
        ...(user.schoolId ? { schoolId: user.schoolId } : {}),
      },
    });

    if (!membership) {
      throw new ForbiddenException(
        'You are not a member of the active school',
      );
    }

    return membership;
  }

  // --------------------------------------------------
  // CREATE RESULT
  // --------------------------------------------------

  async create(
    user: RequestUser,
    dto: CreateResultDto,
  ) {
    // Only teachers and school admins can enter results
    if (
      user.role !== UserRole.TEACHER &&
      user.role !== UserRole.SCHOOL_ADMIN
    ) {
      throw new ForbiddenException(
        'You are not allowed to enter results',
      );
    }

    // Find user's school
    const membership =
      await this.prisma.schoolMembership.findFirst({
        where: {
          userId: user.id,
          ...(user.schoolId ? { schoolId: user.schoolId } : {}),
        },
      });

    if (!membership) {
      throw new ForbiddenException(
        'You are not a member of any school',
      );
    }

    const schoolId = membership.schoolId;

    // --------------------------------------------------
    // Find examination
    // --------------------------------------------------

    const examination =
      await this.prisma.examination.findFirst({
        where: {
          id: dto.examinationId,
          schoolId,
        },
        include: {
          class: true,
          term: true,
          subjects: true,
        },
      });

    if (!examination) {
      throw new NotFoundException(
        'Examination not found in this school',
      );
    }

    // Results can only be entered when exam is OPEN
    if (
      examination.status !==
      ExaminationStatus.OPEN
    ) {
      throw new ConflictException(
        'Results can only be entered for an open examination',
      );
    }

    // --------------------------------------------------
    // Find student
    // --------------------------------------------------

    const student =
      await this.prisma.student.findFirst({
        where: {
          id: dto.studentId,
          schoolId,
        },
      });

    if (!student) {
      throw new NotFoundException(
        'Student not found in this school',
      );
    }

    // --------------------------------------------------
    // Check student is enrolled in exam class
    // --------------------------------------------------

    const enrollment =
      await this.prisma.enrollment.findFirst({
        where: {
          studentId: dto.studentId,
          classId: examination.classId,
          status: 'ACTIVE',
        },
      });

    if (!enrollment) {
      throw new ForbiddenException(
        'Student is not enrolled in the examination class',
      );
    }

    // --------------------------------------------------
    // Find examination subject
    // --------------------------------------------------

    const examinationSubject =
      await this.prisma.examinationSubject.findUnique({
        where: {
          examinationId_subjectId: {
            examinationId: dto.examinationId,
            subjectId: dto.subjectId,
          },
        },
        include: {
          subject: true,
        },
      });

    if (!examinationSubject) {
      throw new NotFoundException(
        'This subject is not part of the examination',
      );
    }

    // --------------------------------------------------
    // Teacher authorization
    // --------------------------------------------------

    let teacherId: string | undefined;

    if (user.role === UserRole.TEACHER) {
      const teacher =
        await this.prisma.teacher.findUnique({
          where: {
            userId: user.id,
            ...(user.schoolId ? { schoolId: user.schoolId } : {}),
          },
        });

      if (!teacher) {
        throw new NotFoundException(
          'Teacher profile not found',
        );
      }

      // Teacher must be assigned to the examination class
      const classAssignment =
        await this.prisma.classTeacher.findUnique({
          where: {
            classId_teacherId: {
              classId: examination.classId,
              teacherId: teacher.id,
            },
          },
        });

      if (!classAssignment) {
        throw new ForbiddenException(
          'You are not assigned to this class',
        );
      }

      // Teacher must also be assigned to this subject
      const subjectAssignment =
        await this.prisma.teacherSubject.findUnique({
          where: {
            teacherId_subjectId: {
              teacherId: teacher.id,
              subjectId: dto.subjectId,
            },
          },
        });

      if (!subjectAssignment) {
        throw new ForbiddenException(
          'You are not assigned to this subject',
        );
      }

      teacherId = teacher.id;
    }

    // --------------------------------------------------
    // Validate scores
    // --------------------------------------------------

    const caScore = dto.caScore ?? 0;
    const examScore = dto.examScore ?? 0;

    const totalScore = caScore + examScore;

    if (
      totalScore >
      examinationSubject.maxScore
    ) {
      throw new ConflictException(
        `Total score cannot exceed ${examinationSubject.maxScore}`,
      );
    }

    // --------------------------------------------------
    // Check duplicate result
    // --------------------------------------------------

    const existingResult =
      await this.prisma.result.findUnique({
        where: {
          studentId_examinationId_subjectId: {
            studentId: dto.studentId,
            examinationId: dto.examinationId,
            subjectId: dto.subjectId,
          },
        },
      });

    if (existingResult) {
      throw new ConflictException(
        'A result already exists for this student, examination and subject',
      );
    }

    // --------------------------------------------------
    // Calculate grade
    // --------------------------------------------------

    const grade = await this.computeGrade(
      schoolId,
      totalScore,
      examinationSubject.maxScore,
    );

    // --------------------------------------------------
    // Create result
    // --------------------------------------------------

    return this.prisma.result.create({
      data: {
        studentId: dto.studentId,
        examinationId: dto.examinationId,
        subjectId: dto.subjectId,
        teacherId,
        termId: examination.termId,
        caScore,
        examScore,
        totalScore,
        grade,
        remark: dto.remark,
      },
      include: {
        student: true,
        examination: true,
        subject: true,
        teacher: true,
        term: true,
      },
    });
  }

  // --------------------------------------------------
  // FIND ALL
  // --------------------------------------------------


  async findMine(user: RequestUser) {
    if (user.role !== UserRole.STUDENT && user.role !== UserRole.PARENT) {
      throw new ForbiddenException(
        'Only students and parents can view their own results',
      );
    }

    const membership = await this.getMembership(user);
    let studentIds: string[];
    if (user.role === UserRole.STUDENT) {
      const student = await this.prisma.student.findFirst({
        where: { userId: user.id, schoolId: membership.schoolId },
        select: { id: true },
      });
      if (!student) throw new NotFoundException('Student profile not found');
      studentIds = [student.id];
    } else {
      const parent = await this.prisma.parent.findFirst({
        where: { userId: user.id, schoolId: membership.schoolId },
        include: { children: { select: { studentId: true } } },
      });
      if (!parent) throw new NotFoundException('Parent profile not found');
      studentIds = parent.children.map(({ studentId }) => studentId);
      if (!studentIds.length) return [];
    }

    return this.prisma.result.findMany({
      where: {
        studentId: { in: studentIds },
        examination: {
          schoolId: membership.schoolId,
          status: ExaminationStatus.PUBLISHED,
        },
      },
      include: {
        student: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            admissionNumber: true,
          },
        },
        examination: true,
        subject: true,
        term: true,
        teacher: {select: { id: true, firstName: true, lastName:true}},
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findAll(user: RequestUser) {
    if (
      user.role !== UserRole.SCHOOL_ADMIN &&
      user.role !== UserRole.SUPER_ADMIN &&
      user.role !== UserRole.TEACHER
    ) {
      throw new ForbiddenException(
        'You are not allowed to view all school results',
      );
    }

    const membership = await this.getMembership(user);
    const where: Prisma.ResultWhereInput = {
      examination: { schoolId: membership.schoolId },
    };

    if (user.role === UserRole.TEACHER) {
      const teacher = await this.prisma.teacher.findUnique({
        where: { userId: user.id },
        include: { classAssignments: { select: { classId: true } } },
      });

      if (!teacher) {
        throw new NotFoundException('Teacher profile not found');
      }

      const classIds = teacher.classAssignments.map(
        (assignment) => assignment.classId,
      );
      if (classIds.length === 0) {
        return [];
      }

      where.examination = {
        schoolId: membership.schoolId,
        classId: { in: classIds },
      };
    }

    return this.prisma.result.findMany({
      where,
      include: {
        student: true,
        examination: true,
        subject: true,
        teacher: true,
        term: true,
      },
      orderBy: {
        createdAt: 'desc',
      },
    });
  }

  // --------------------------------------------------
  // FIND ONE
  // --------------------------------------------------

  async findOne(
    user: RequestUser,
    id: string,
  ) {
    const membership = await this.getMembership(user);
    const where: Prisma.ResultWhereInput = {
      id,
      examination: { schoolId: membership.schoolId },
    };

    if (user.role === UserRole.STUDENT) {
      const student = await this.prisma.student.findFirst({
        where: { userId: user.id, schoolId: membership.schoolId },
        select: { id: true },
      });
      if (!student) {
        throw new NotFoundException('Student profile not found');
      }
      where.studentId = student.id;
      where.examination = {
        schoolId: membership.schoolId,
        status: ExaminationStatus.PUBLISHED,
      };
    } else if (user.role === UserRole.PARENT) {
      const parent = await this.prisma.parent.findFirst({
        where: { userId: user.id, schoolId: membership.schoolId },
        select: { id: true },
      });
      if (!parent) {
        throw new NotFoundException('Parent profile not found');
      }
      where.student = {
        guardians: { some: { parentId: parent.id } },
      };
      where.examination = {
        schoolId: membership.schoolId,
        status: ExaminationStatus.PUBLISHED,
      };
    } else if (user.role === UserRole.TEACHER) {
      const teacher = await this.prisma.teacher.findUnique({
        where: { userId: user.id },
        include: { classAssignments: { select: { classId: true } } },
      });
      if (!teacher) {
        throw new NotFoundException('Teacher profile not found');
      }
      where.examination = {
        schoolId: membership.schoolId,
        classId: {
          in: teacher.classAssignments.map((assignment) => assignment.classId),
        },
      };
    } else if (
      user.role !== UserRole.SCHOOL_ADMIN &&
      user.role !== UserRole.SUPER_ADMIN
    ) {
      throw new ForbiddenException('You are not allowed to view this result');
    }

    const result =
      await this.prisma.result.findFirst({
        where,
        include: {
          student: true,
          examination: {
            include: {
              class: true,
            },
          },
          subject: true,
          teacher: true,
          term: true,
        },
      });

    if (!result) {
      throw new NotFoundException(
        'Result not found',
      );
    }

    return result;
  }

  // --------------------------------------------------
  // UPDATE RESULT
  // --------------------------------------------------

  async update(
    user: RequestUser,
    id: string,
    dto: UpdateResultDto,
  ) {
    if (
      user.role !== UserRole.TEACHER &&
      user.role !== UserRole.SCHOOL_ADMIN
    ) {
      throw new ForbiddenException(
        'You are not allowed to update results',
      );
    }

    const membership =
      await this.prisma.schoolMembership.findFirst({
        where: {
          userId: user.id,
          ...(user.schoolId ? { schoolId: user.schoolId } : {}),
        },
      });

    if (!membership) {
      throw new ForbiddenException(
        'You are not a member of any school',
      );
    }

    const result =
      await this.prisma.result.findFirst({
        where: {
          id,
          examination: {
            schoolId: membership.schoolId,
          },
        },
        include: {
          examination: true,
        },
      });

    if (!result) {
      throw new NotFoundException(
        'Result not found',
      );
    }

    // Results cannot be changed after publication
    if (
      result.examination.status ===
      ExaminationStatus.PUBLISHED
    ) {
      throw new ConflictException(
        'Published results cannot be modified',
      );
    }

    // Teacher authorization
    if (user.role === UserRole.TEACHER) {
      const teacher =
        await this.prisma.teacher.findUnique({
          where: {
            userId: user.id,
          },
        });

      if (!teacher) {
        throw new NotFoundException(
          'Teacher profile not found',
        );
      }

      if (result.teacherId !== teacher.id) {
        throw new ForbiddenException(
          'You can only update results you entered',
        );
      }
    }

    const caScore =
      dto.caScore ?? result.caScore ?? 0;

    const examScore =
      dto.examScore ?? result.examScore ?? 0;

    // Find max score
    const examinationSubject =
      await this.prisma.examinationSubject.findUnique({
        where: {
          examinationId_subjectId: {
            examinationId: result.examinationId,
            subjectId: result.subjectId,
          },
        },
      });

    if (!examinationSubject) {
      throw new NotFoundException(
        'Examination subject not found',
      );
    }

    const totalScore =
      caScore + examScore;

    if (
      totalScore >
      examinationSubject.maxScore
    ) {
      throw new ConflictException(
        `Total score cannot exceed ${examinationSubject.maxScore}`,
      );
    }

    const grade = await this.computeGrade(
      membership.schoolId,
      totalScore,
      examinationSubject.maxScore,
    );

    return this.prisma.result.update({
      where: {
        id,
      },
      data: {
        caScore,
        examScore,
        totalScore,
        grade,
        ...(dto.remark !== undefined && {
          remark: dto.remark,
        }),
      },
      include: {
        student: true,
        examination: true,
        subject: true,
        teacher: true,
        term: true,
      },
    });
  }
 

  // --------------------------------------------------
  // DELETE RESULT
  // --------------------------------------------------

  async remove(
    user: RequestUser,
    id: string,
  ) {
    if (user.role !== UserRole.SCHOOL_ADMIN) {
      throw new ForbiddenException(
        'Only school admins can delete results',
      );
    }

    const membership =
      await this.prisma.schoolMembership.findFirst({
        where: {
          userId: user.id,
          role: UserRole.SCHOOL_ADMIN,
        },
      });

    if (!membership) {
      throw new ForbiddenException(
        'You are not a school admin',
      );
    }

    const result =
      await this.prisma.result.findFirst({
        where: {
          id,
          examination: {
            schoolId: membership.schoolId,
          },
        },
        include: {
          examination: true,
        },
      });

    if (!result) {
      throw new NotFoundException(
        'Result not found',
      );
    }

    if (
      result.examination.status ===
      ExaminationStatus.PUBLISHED
    ) {
      throw new ConflictException(
        'Published results cannot be deleted',
      );
    }

    return this.prisma.result.delete({
      where: {
        id,
      },
    });
  }

  // --------------------------------------------------
  // GRADE CALCULATION
  // --------------------------------------------------
  // Uses the school's own grading scale, or the built-in A-F scale
  // if the school has not set one up.
  private async computeGrade(
    schoolId: string,
    totalScore: number,
    maxScore: number,
  ): Promise<string> {
    const { bands } = await this.gradingService.getEffectiveBands(schoolId);

    return gradeFor(bands, percentageOf(totalScore, maxScore)).grade;
  }
}